package mainpkg;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Ishti
 */
public class LoginPageController implements Initializable {

    @FXML private TextField idTextField;
    @FXML private TextField passwordTextField;
    @FXML private Text errorMessage;
    public String id,pass;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void loginButtonOnClick(MouseEvent event)throws IOException {
        //Parent scene2Parent = FXMLLoader.load(getClass().getResource("Administrator.fxml"));
        //Parent scene3Parent = FXMLLoader.load(getClass().getResource("passenger.fxml"));
        id=idTextField.getText();
        pass=passwordTextField.getText();
        int i=Integer.parseInt(id);
        if(i==125)
            {
                Parent scene2Parent = FXMLLoader.load(getClass().getResource("Administrator.fxml"));
                Scene scene2 = new Scene(scene2Parent);
                Stage stg2 = (Stage)((Node)event.getSource()).getScene().getWindow(); 
                stg2.setScene(scene2);
            }
        
            
            
            
            
            /*
        
            Parent scene3Parent = FXMLLoader.load(getClass().getResource("passenger.fxml"));
            Scene scene3 = new Scene(scene3Parent);
            Stage stg3 = (Stage)((Node)event.getSource()).getScene().getWindow(); 
            stg2.setScene(scene3);
            
            */
        
                  
               
            
    }
        
        
        
    }
    

