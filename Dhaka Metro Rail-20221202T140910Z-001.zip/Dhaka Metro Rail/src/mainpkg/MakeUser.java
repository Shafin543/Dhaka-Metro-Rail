package mainpkg;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;
/**
 *
 * @author Ishti
 */
public class MakeUser {
    public static void main(String[] args) throws IOException{
        
        int id;
        String password,type;
        
        Scanner s=new Scanner(System.in);
        //System.out.print("Enter newUser Id: ");
        id=s.nextInt();
        //s.nextLine();
        //System.out.print("Enter new Password: ");
        password=s.nextLine();
        s.nextLine();
        //System.out.print("Enter newUser Type: ");
        type=s.nextLine();
        User a=new User(password,id,type);
        
                FileOutputStream fos = new FileOutputStream("UserData.bin",true);
                DataOutputStream dos = new DataOutputStream(fos);
                
                dos.writeUTF(a.getPassword());
                dos.writeInt(a.getId());
                dos.writeUTF(a.getUserType());
                
                dos.close();
            
                      


            //2: write the Student instance using object stream
            
                FileOutputStream fis = new FileOutputStream("UserObjects.bin",true);
                ObjectOutputStream oos = new ObjectOutputStream(fis);
                
                oos.writeObject(a);
                oos.close();
            
    }
}
