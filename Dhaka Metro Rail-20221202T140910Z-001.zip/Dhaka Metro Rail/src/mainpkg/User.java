
package mainpkg;

/**
 *
 *@author Ishti
 * 
 */
public class User {
    
    protected String password;
    protected int id;
    protected String userType;
    
    public User(String password,int id,String userType)
    {
        this.password=password;
        this.id=id;
        this.userType=userType;
    }
    protected boolean verify()
    {
        return true;
    }
    public boolean verifyLogin()
    {
        
        return true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    
    
}
